path = paste(system.file(package="swirl"), "/Courses/Biostats_753/Regular_Expressions_2/data.RData", sep="")
load(path)
